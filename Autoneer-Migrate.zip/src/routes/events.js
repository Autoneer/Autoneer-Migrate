const express = require("express");
const { getEmitter, getRunState } = require("../migrate/runner");
const logger = require("../migrate/logger");

const router = express.Router();

const handleProgressStream = (req, res) => {
	const runIdRaw = req.query.runId;
	const runId = Number(runIdRaw);

	// Fix: Add logging for SSE connections
	console.log(`SSE connection for runId: ${runId} from IP: ${req.ip}`);

	if (!runId) {
		res.status(400).end();
		return;
	}

	res.setHeader("Content-Type", "text/event-stream");
	res.setHeader("Cache-Control", "no-cache");
	res.setHeader("Connection", "keep-alive");
	res.setHeader("X-Accel-Buffering", "no");
	if (typeof res.flushHeaders === "function") {
		res.flushHeaders();
	}

	const emitter = getEmitter(runId);
	const runState = getRunState(runId);
	const logEmitter = logger.getLogEmitter(runId) || logger.startRunLogger(runId);
	const logBuffer = logger.getLogBuffer(runId);
	if (!emitter && !runState) {
		res.write(`event: message\ndata: ${JSON.stringify({ type: "not_found" })}\n\n`);
		res.end();
		return;
	}

	// Root cause note: SSE disconnects previously triggered UI failure even when the runner kept inserting.
	// We now treat SSE drop as non-fatal and rely on server-run state + reconnection.
	logger.logEvent(runId, { level: "info", phase: "progress", status: "client_connected" });

	// Centralized cleanup to avoid leaks on any termination or error
	let cleaned = false;
	const cleanup = () => {
		if (cleaned) return;
		cleaned = true;

		clearInterval(heartbeat);

		if (emitter) {
			emitter.removeListener("event", onEvent);
		}
		if (logEmitter) {
			logEmitter.removeListener("log", onLog);
		}

		try {
			logger.logEvent(runId, { level: "warn", phase: "progress", status: "client_disconnected" });
		} catch (err) {
			console.warn('Failed to log client_disconnected for SSE', err && err.message);
		}
	};

	// Safe write wrapper
	const safeWrite = (data) => {
		try {
			res.write(data);
		} catch (err) {
			console.error('SSE write failed:', err && err.message);
			cleanup();
		}
	};

	if (runState) {
		safeWrite(`event: runState\ndata: ${JSON.stringify(runState)}\n\n`);
	}

	if (logBuffer.length) {
		logBuffer.forEach((entry) => {
			safeWrite(`event: log\ndata: ${JSON.stringify(entry)}\n\n`);
		});
	}

	const onEvent = (payload) => {
		if (payload?.event === "runState") {
			safeWrite(`event: runState\ndata: ${JSON.stringify(payload.data)}\n\n`);
			return;
		}
		safeWrite(`data: ${JSON.stringify(payload)}\n\n`);
	};

	const onLog = (entry) => {
		safeWrite(`event: log\ndata: ${JSON.stringify(entry)}\n\n`);
	};

	const heartbeat = setInterval(() => {
		try {
			safeWrite(": ping\n\n");
		} catch (err) {
			console.error('SSE heartbeat failed:', err && err.message);
			cleanup();
		}
	}, 15000);

	if (emitter) {
		emitter.on("event", onEvent);
	}
	if (logEmitter) {
		logEmitter.on("log", onLog);
	}

	// Cleanup on various termination events
	req.on("close", cleanup);
	req.on("error", cleanup);
	res.on("error", cleanup);
	res.on("finish", cleanup);
	return;
};

router.get("/events", handleProgressStream);
router.get("/run/progress", handleProgressStream);

module.exports = router;
