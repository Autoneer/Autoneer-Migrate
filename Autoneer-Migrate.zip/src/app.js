const path = require("path");
const express = require("express");
const bodyParser = require("body-parser");
const { engine } = require("express-handlebars");
require("dotenv").config();

const setupRoutes = require("./routes/setup");
const eventsRoutes = require("./routes/events");
const migrationRoutes = require("./routes/migration");
const wizardRoutes = require("./routes/wizard"); // Phase 3: New wizard UI
const { router: healthRoutes } = require("./routes/health"); // Destructure router since health.js exports object
const schemaRoutes = require("./routes/schema"); // New refactored schema API

// Phase 2 API routes - Refactored models
const mappingApiRoutes = require("./routes/api/mappings");
const planApiRoutes = require("./routes/api/plans");
const runApiRoutes = require("./routes/api/runs");

const app = express();

app.engine(
	"hbs",
	engine({
		extname: ".hbs",
		defaultLayout: "main",
		layoutsDir: path.join(__dirname, "views", "layouts"),
		partialsDir: path.join(__dirname, "views", "partials"),
		helpers: {
			eq: (a, b) => a === b,
			includes: (arr, value) => Array.isArray(arr) && arr.includes(value),
			json: (context) => JSON.stringify(context, null, 2),
			lookup: (obj, field) => (obj ? obj[field] : undefined),
			formatDate: (value, format) => {
				if (!value) return '-';
				const d = value instanceof Date ? value : new Date(value);
				if (isNaN(d.getTime())) return value;
				const opts = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
				if (format === 'date') delete opts.hour, delete opts.minute;
				try {
					return d.toLocaleString('en-US', opts);
				} catch (e) {
					return d.toString();
				}
			}
		}
	})
);
app.set("view engine", "hbs");
app.set("views", path.join(__dirname, "views"));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json({ limit: "1mb" }));

app.use("/public", express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => res.redirect("/setup"));

app.use(setupRoutes);
app.use(migrationRoutes);
app.use(wizardRoutes); // Phase 3: Wizard UI route
app.use(eventsRoutes);
app.use(healthRoutes);
app.use(schemaRoutes); // New schema API routes

// Phase 2: Refactored API routes
app.use("/api", mappingApiRoutes); // Mapping CRUD endpoints
app.use("/api", planApiRoutes);    // Plan management endpoints
app.use("/api", runApiRoutes);     // Run tracking endpoints

app.use((err, req, res, next) => {
	const message = err?.message || "Unexpected error";
	res.status(500).render("error", { message });
});

const port = process.env.PORT || 3000;
const server = app.listen(port, () => {
	console.log(`Autoneer migrator running on http://localhost:${port}`);
});

// Graceful shutdown handler
async function gracefulShutdown(reason) {
	console.log(`\n${reason} - Initiating graceful shutdown...`);

	try {
		// Close HTTP server (stop accepting new connections)
		await new Promise((resolve) => {
			server.close(() => {
				console.log('HTTP server closed');
				resolve();
			});
		});

		// Close MySQL pools
		try {
			const { mysqlPoolCache } = require('./routes/health');
			for (const [schemaName, pool] of mysqlPoolCache.entries()) {
				try {
					await pool.end();
					console.log(`Closed MySQL pool for schema: ${schemaName}`);
				} catch (err) {
					console.error(`Error closing pool for ${schemaName}:`, err && err.message);
				}
			}
		} catch (err) {
			console.warn('No mysql pools to close or error while closing pools:', err && err.message);
		}

		// Flush logs
		try {
			const logger = require('./migrate/logger');
			if (typeof logger.flush === 'function') {
				await logger.flush();
			}
		} catch (err) {
			// ignore logger flush failures
		}

		console.log('Graceful shutdown complete');
		process.exit(0);
	} catch (err) {
		console.error('Error during shutdown:', err);
		process.exit(1);
	}
}

server.on('error', async (err) => {
	if (err && err.code === 'EADDRINUSE') {
		console.error(`\n❌ Port ${port} is already in use.`);
		console.error(`   Please either:`);
		console.error(`   1. Stop the other process using port ${port}`);
		console.error(`   2. Set a different PORT environment variable`);
		console.error(`   Example: PORT=3001 npm start\n`);

		await gracefulShutdown('Port conflict');
	} else {
		console.error('Server error:', err);
		await gracefulShutdown('Server error');
	}
});

// Handle termination signals
process.on('SIGTERM', () => gracefulShutdown('SIGTERM signal'));
process.on('SIGINT', () => gracefulShutdown('SIGINT signal (Ctrl+C)'));

// Handle uncaught errors
process.on('uncaughtException', (err) => {
	console.error('Uncaught exception:', err);
	gracefulShutdown('Uncaught exception');
});

process.on('unhandledRejection', (reason, promise) => {
	console.error('Unhandled rejection at:', promise, 'reason:', reason);
	gracefulShutdown('Unhandled rejection');
});
