const assert = require('assert');
const { normalizePlanSteps } = require('../src/migrate/planNormalize');

(function testArrayDefaultsAndExplicitBooleans() {
	const plan = [
		{ table: 'a' },
		{ table: 'b', cleanBefore: false },
		{ table: 'c', cleanBefore: true }
	];
	const normalized = normalizePlanSteps(plan);
	assert.strictEqual(normalized[0].cleanBefore, false, 'default cleanBefore should be false');
	assert.strictEqual(normalized[1].cleanBefore, false, 'explicit false must be preserved');
	assert.strictEqual(normalized[2].cleanBefore, true, 'explicit true must be preserved');
})();

(function testObjectTablesShape() {
	const plan = {
		tables: {
			users: { cleanBefore: false },
			orders: {}
		}
	};
	const normalized = normalizePlanSteps(plan);
	const users = normalized.find(x => x.table === 'users');
	const orders = normalized.find(x => x.table === 'orders');
	assert.ok(users, 'users entry exists');
	assert.ok(orders, 'orders entry exists');
	assert.strictEqual(users.cleanBefore, false, 'explicit false preserved for object shape');
	assert.strictEqual(orders.cleanBefore, false, 'missing value defaults to false');
})();

console.log('Plan normalization tests passed.');
