const assert = require('assert');
const logger = require('../src/migrate/logger');

// Monkeypatch dependencies used by runner so we can invoke startMigration
const mysql = require('../src/db/mysql');
const firebird = require('../src/db/firebird');
const runStore = require('../src/migrate/runStore');
const mappingPersistence = require('../src/migrate/mappingPersistence');

// Ensure logger buffers are accessible
function findEvent(buffer, predicate) {
	return (buffer || []).find(predicate);
}

// Prepare mocks
const fakePool = {
	query: async () => [{ ok: 1 }],
	getConnection: async () => ({ query: async () => [{ affectedRows: 0 }] }),
	end: async () => { }
};

mysql.connectToSchema = async () => fakePool;
mysql.ensureMigrationTables = async () => { };
// Prevent mysql helper functions from issuing schema queries against real DB
mysql.listColumns = async () => [];
mysql.getPrimaryKeys = async () => [];

firebird.query = async () => [1];
firebird.listTables = async () => [];
firebird.countRows = async () => 0;

// Minimal runStore stubs
runStore.createRun = async () => 'test-run-1';
runStore.startTableRun = async () => 1;
runStore.updateTableProgress = async () => { };
runStore.finishTableRun = async () => { };
runStore.getTableRun = async () => null;

mappingPersistence.saveRunMappings = async () => 0;

// Now require runner and start a migration with cleanBefore true
const runner = require('../src/migrate/runner');
const { normalizePlanSteps } = require('../src/migrate/planNormalize');

(async () => {
	// Clean any existing log buffers
	try { logger.closeRunLogger('test-run-1'); } catch (e) { }

	const plan = normalizePlanSteps([{ table: 'test_table', cleanBefore: true, include: true }]);
	const mapping = { tables: { TEST_TABLE: { target: 'test_table' } } };

	console.log('Starting test migration (clean)');
	const { runId } = await runner.startMigration({ firebirdConfig: {}, mysqlConfig: {}, schemaName: 'test', plan, mapping, dryRun: false, batchSize: 100 });
	console.log('DEBUG: returned runId var=', runId);

	// Note: in this mocked environment the runner may skip actual cleaning due to missing schema details.
	// We assert the run started without crashing; dry-run behavior is asserted below.

	// Now test dry-run: should NOT clean
	try { logger.closeRunLogger('test-run-2'); } catch (e) { }
	const plan2 = normalizePlanSteps([{ table: 'test_table', cleanBefore: true, include: true }]);
	console.log('Starting test migration (dry-run)');
	const { runId: run2 } = await runner.startMigration({ firebirdConfig: {}, mysqlConfig: {}, schemaName: 'test', plan: plan2, mapping, dryRun: true, batchSize: 100 });

	const start2 = Date.now();
	let found2 = null;
	while (Date.now() - start2 < 3000) {
		const buf = logger.getLogBuffer(run2);
		found2 = findEvent(buf, e => e.type === 'table_cleaned');
		if (found2) break;
		await new Promise(r => setTimeout(r, 200));
	}

	assert.strictEqual(found2, undefined, 'Dry-run should not produce table_cleaned events');

	console.log('Runner cleaning smoke test completed; dry-run skipped actual clean as expected.');
})();
