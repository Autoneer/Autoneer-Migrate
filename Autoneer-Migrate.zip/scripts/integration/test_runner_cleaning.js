#!/usr/bin/env node
/*
Integration test for runner cleaning logic (TRUNCATE -> DELETE fallback).

Requires MySQL connection env vars:
  MYSQL_HOST, MYSQL_PORT, MYSQL_USER, MYSQL_PASSWORD, MYSQL_DB

If env vars are not set, the script exits with instructions.
*/
const mysql = require('mysql2/promise');

async function main() {
	const host = process.env.MYSQL_HOST;
	const port = process.env.MYSQL_PORT || 3306;
	const user = process.env.MYSQL_USER;
	const password = process.env.MYSQL_PASSWORD;
	const database = process.env.MYSQL_DB;

	if (!host || !user || !password || !database) {
		console.error('\nMissing MySQL connection environment variables.');
		console.error('Set MYSQL_HOST, MYSQL_USER, MYSQL_PASSWORD, MYSQL_DB (optionally MYSQL_PORT) and re-run.');
		process.exit(2);
	}

	const conn = await mysql.createConnection({ host, port, user, password, database });
	console.log('Connected to MySQL at', host + ':' + port, 'db=', database);

	// Ensure migration_table_runs exists with cleaned column
	await ensureMigrationTableRuns(conn);

	// Names for test tables
	const parent = 'int_test_parent_cleanup';
	const child = 'int_test_child_cleanup';

	try {
		// Clean any leftovers
		await safeExec(conn, `DROP TABLE IF EXISTS \`${child}\``);
		await safeExec(conn, `DROP TABLE IF EXISTS \`${parent}\``);

		// Create parent table
		await conn.execute(`CREATE TABLE \`${parent}\` (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(100)) ENGINE=InnoDB`);
		// Create child table with ON DELETE CASCADE so DELETE will succeed even if TRUNCATE is blocked
		await conn.execute(`CREATE TABLE \`${child}\` (id INT PRIMARY KEY AUTO_INCREMENT, parent_id INT, CONSTRAINT fk_parent FOREIGN KEY (parent_id) REFERENCES \`${parent}\`(id) ON DELETE CASCADE) ENGINE=InnoDB`);

		// Insert sample rows
		const [r1] = await conn.execute(`INSERT INTO \`${parent}\` (name) VALUES ('a'),('b'),('c')`);
		const parentInserted = r1.affectedRows || 3;
		// Insert child rows referencing parent
		await conn.execute(`INSERT INTO \`${child}\` (parent_id) VALUES (1),(2),(3)`);

		console.log(`Inserted ${parentInserted} rows into ${parent} and matching child rows into ${child}`);

		// Attempt TRUNCATE (expected to fail due to FK)
		let method = null;
		try {
			await conn.execute(`TRUNCATE TABLE \`${parent}\``);
			method = 'TRUNCATE';
			console.log('TRUNCATE succeeded');
		} catch (err) {
			console.warn('TRUNCATE failed (expected in FK setup), falling back to DELETE:', err.message);
			// Fallback to DELETE
			const [del] = await conn.execute(`DELETE FROM \`${parent}\``);
			method = 'DELETE';
			console.log(`DELETE affectedRows=${del.affectedRows}`);
		}

		// Verify parent table is empty
		const [rowsAfter] = await conn.execute(`SELECT COUNT(*) as c FROM \`${parent}\``);
		const count = rowsAfter[0].c;
		console.log(`Rows in ${parent} after cleaning: ${count}`);

		// Simulate persisting cleaned flag to migration_table_runs
		const [ins] = await conn.execute(`INSERT INTO migration_table_runs (run_id, table_name, status, cleaned) VALUES (?, ?, ?, ?)`, ['integration-run-1', parent, 'CLEANED', 1]);
		console.log('Inserted migration_table_runs row id=', ins.insertId);

		// Read back cleaned flag
		const [q] = await conn.execute(`SELECT cleaned FROM migration_table_runs WHERE id = ?`, [ins.insertId]);
		console.log('Persisted cleaned flag:', q[0].cleaned);

		console.log('\nIntegration test: SUCCESS — cleanup method:', method);

	} finally {
		// Cleanup test tables
		await safeExec(conn, `DROP TABLE IF EXISTS \`${child}\``);
		await safeExec(conn, `DROP TABLE IF EXISTS \`${parent}\``);
		await conn.end();
		console.log('Cleaned up and closed connection');
	}
}

async function ensureMigrationTableRuns(conn) {
	// Create simple migration_table_runs if missing
	await conn.execute(`CREATE TABLE IF NOT EXISTS migration_table_runs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    run_id VARCHAR(255),
    table_name VARCHAR(255),
    status VARCHAR(64),
    cleaned TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB`);
}

async function safeExec(conn, sql) {
	try {
		await conn.execute(sql);
	} catch (e) {
		// ignore
	}
}

main().catch(err => {
	console.error('Integration test failed:', err);
	process.exit(3);
});
